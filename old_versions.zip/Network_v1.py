import math
import numpy as np
import matplotlib.pyplot as plt
runtime = 100

############################################################################ Retina to v1 weight kernels

def areal_filtering(x,y,kernel_size=0):
    a_2 = math.log(2) / math.pi                            # a^2
    return math.exp(-(math.pi / a_2)*(x * x + y * y)) / a_2

def gaussian_kernel(kernel_size,angle):
    kernel = np.zeros((kernel_size,kernel_size))
    for row in range(kernel_size):
        for column in range(kernel_size):
            if angle % 90 == 0:
                kernel[row][column] = areal_filtering((row - math.floor(kernel_size / 2.0)) * math.cos(math.radians(angle)),(column - math.floor(kernel_size / 2.0)) * math.sin(math.radians(angle)),kernel_size)
            else:
                kernel[row][column] = areal_filtering((row - math.floor(kernel_size / 2.0)) * math.cos(math.radians(angle)) - (column - math.floor(kernel_size / 2.0)) * math.sin(math.radians(angle)),(column - math.floor(kernel_size / 2.0)) * math.cos(math.radians(angle)) - (row - math.floor(kernel_size / 2.0)) * math.sin(math.radians(angle)),kernel_size)
    
    return kernel

kernel_size = 5
kernels = []

for orientation in range(0,180,45):
    kernels.append(gaussian_kernel(kernel_size,orientation))
    
#######################################################################   The network

from ImageToSpikes import ImageToSpikes
from Layer import Layer
from pyNN.utility import Timer
from pyNN.nest import *
from SpykeTorch import utils as ut

setup(timestep=0.5, min_delay = 0.5, max_delay = 11.0)
stdp = STDPMechanism(
    weight=0.02,
    timing_dependence=SpikePairRule(tau_plus=20.0, tau_minus=20.0,A_plus=0.05, A_minus=0.0675),
    weight_dependence=AdditiveWeightDependence(w_min=0, w_max=20.0))

timer = Timer()
timer.start()
input_population_size = 10
stride = 1

filter = ut.Filter([ut.DoGKernel(13,13/9,26/9)],padding = 6, thresholds = 50)
retina = ImageToSpikes("5.jpg",filter)
retina_spikes = retina.to_spikes(input_population_size,input_population_size)


orientation_features = 4
population_sizes = []
for i in range(orientation_features):
    population_sizes.append(int((1 + (input_population_size - kernel_size) / stride) * (1 + (input_population_size - kernel_size) / stride)))

lip_size = int(population_sizes[0] / 2)    
neurons_type = IF_curr_exp

input_layer = Layer('retina')
v1 = Layer('v_1')
v2 = Layer('v_2')
v4 = Layer('v_4')
lip = Layer('lip')

input_layer.add_populations(SpikeSourceArray,[input_population_size*input_population_size],retina_spikes)

mid_layers = [v1,v2,v4]

for layer in mid_layers:
    layer.add_populations(neurons_type,population_sizes)

population_sizes = [int(size / 2) for size in population_sizes]
layer.add_populations(neurons_type,population_sizes)
lip.add_populations(neurons_type,[lip_size])

####################################################################3 Connections

input_layer.connect_with_given_kernel_weights(v1,kernels)
v1.connect_layers(v2,"one",8) #60
v2.connect_layers(v4,"all",5,stdp) #205
v4.connect_layers(lip,"choose",22) #22


v1.populations[0].record('spikes') #v1
lip.populations[0][0:3].record(['v'])
setup_time = timer.elapsedTime()
run(runtime)
run_time = timer.elapsedTime()
############################################################ Plotting
#for amp in(-0.2, -0.1, 0.0, 0.1, 0.2):
#	step_current.amplitude = amp
#	run(100.0)
#	reset(annotations={"amplitude": amp*nA})
#lip_array = np.zeros((10,10),float)
lip_spikes = v1.populations[0].get_data() #v1
fig_settings = {
	'lines.linewidth': 0.5,
	'axes.linewidth': 0.5,
	'axes.labelsize': 'small',
	'legend.fontsize': 'small',
	'font.size': 8
}
plt.rcParams.update(fig_settings)
plt.figure(1, figsize=(6, 8))

def plot_spiketrains(segment):
	a = 0
	for spiketrain in segment.spiketrains:
		
		a+= 1
		y = np.ones_like(spiketrain) * spiketrain.annotations['source_id']
		#print(spiketrain.annotations['source_id'])
		#print(a)
		plt.plot(spiketrain, y, '.')
		plt.ylabel(segment.name)
		plt.setp(plt.gca().get_xticklabels(), visible=False)
		
def plot_signal(signal, index, colour='b'):
    label = "Neuron %d" % signal.annotations['source_ids'][index]
    plt.plot(signal.times, signal[:, index], colour, label=label)
    plt.ylabel("%s (%s)" % (signal.name, signal.units._dimensionality.string))
    plt.setp(plt.gca().get_xticklabels(), visible=False)
    plt.legend()

n_panels = sum(a.shape[1] for a in lip_spikes.segments[0].analogsignals) + 2
plt.subplot(n_panels, 1, 1)
plot_spiketrains(lip_spikes.segments[0])

panel = 2
#for array in lip_spikes.segments[0].analogsignals:
#    for i in range(array.shape[1]):
#        plt.subplot(n_panels, 1, panel)
#        plot_signal(array, i, colour='bg'[panel % 2])
#        panel += 1
#plt.xlabel("time (100%s)" % array.times.units._dimensionality.string)
#plt.xlabel("time (100ms)")
plt.setp(plt.gca().get_xticklabels(), visible=True)
plt.show()