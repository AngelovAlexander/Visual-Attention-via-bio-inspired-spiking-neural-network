from tkinter import * 
from tkinter.ttk import *
import PIL
from PIL import Image
from PIL import ImageTk
from tkinter import filedialog
from ImageToSpikes import ImageToSpikes
from SpykeTorch import utils as ut
from tkinter import messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

image1 = None
image2 = None
def open_img():
    # Select the Imagename  from a folder 
    global x
    x = openfilename()
  
    # opens the image
    img = Image.open(x)
      
    # resize the image and apply a high-quality down sampling filter
    img = img.resize((200, 200), Image.ANTIALIAS)
  
    # PhotoImage class is used to add image to widgets, icons etc
    img = ImageTk.PhotoImage(img)
   
    # create a label
    panel = Label(frame, image = img)
      
    # set the image as img 
    panel.image = img
    panel.grid(row = 5, column = 1)
    
def openfilename():
  
    # open file dialog box to select image
    # The dialogue box has a title "Open"
    filename = filedialog.askopenfilename(title ='choose image')
    return filename

def give_spikes():
    global image1,image2  # image location
    if image1 == None or image1 == () or image1 == "":
        messagebox.showerror("Error", "You should choose an image to work on!")
    elif neurons.get() <= 0:
        messagebox.showerror("Error", "You should give a positive number for the dimension of the input neural population greater than or equal to 2!")
    elif runtime.get() <= 0:
        messagebox.showerror("Error", "The runtime should be at least 1!")
    elif runtime.get() > neurons.get() * neurons.get():
        
        messagebox.showerror("Error", "The squate of the runtime should be less than the input neurons!")
        
    else:
        # if something is not chosen, give "error message, else do spike conversiaon"
        filter = ut.Filter([ut.DoGKernel(13,13/9,26/9)],padding = 6, thresholds = 50)
        retina = ImageToSpikes(image1,filter)
        retina_spikes = retina.to_spikes(neurons.get(),neurons.get(),runtime.get())
        figure = plt.Figure(figsize=(5,5), dpi=50)
        ax = figure.add_subplot(111)
        retina.plot_spikes(ax)
        spikes = FigureCanvasTkAgg(figure, frame)
        spikes.get_tk_widget().grid(row = 0, column = 4,rowspan = 7, columnspan = 7)
        #plt.show()
        #print(retina_spikes[0])
        #print(retina_spikes[1])
        
        # You should only display a plot with the spikes !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
            
def give_path():
    global x  # image location
    if x == None or x == () or x == "":
        messagebox.showerror("Error", "You should choose an image to work on!")
    elif orientation.get() == 0:
        messagebox.showerror("Error", "Choose orientations!")
    elif neurons.get() <= 0:
        messagebox.showerror("Error", "You should give a positive number for the dimension of the input neural population greater than or equal to 2!")
    elif kernel_size.get() < 2 or kernel_size.get() > neurons.get():
        messagebox.showerror("Error", "Gaussian kernel should have a size of at least 2 and maximum size equal to the given input neural population!")
    elif runtime.get() <= 0:
        messagebox.showerror("Error", "The runtime should be at least 1!")
    elif runtime.get() > neurons.get() * neurons.get():
        messagebox.showerror("Error", "The squate of the runtime should be less than the input neurons!")
        
    else:
        # if something is not chosen, give "error message, else do spike conversiaon"
        filter = ut.Filter([ut.DoGKernel(13,13/9,26/9)],padding = 6, thresholds = 50)
        retina = ImageToSpikes(x,filter)
        retina_spikes = retina.to_spikes(neurons.get(),neurons.get(),runtime.get())
        print(retina_spikes[0])
        print(retina_spikes[1])
    
        if orientation.get() != 0 and neuron_type.get() != 0 and neurons.get() != None and kernel_size.get() != None:
            Label(frame, text ="Tukk").grid(row=10,pady = 5)

def get_normal_page():
    menu = Menu(root)
    root.config(menu=menu)
    function_menu = Menu(menu)
    menu.add_cascade(label='Functions', menu=function_menu)
    function_menu.add_command(label='Get Spikes', command=spike_window)
    function_menu.add_command(label='Observe path')
    function_menu.add_command(label='Compare two images')
    function_menu.add_separator()
    function_menu.add_command(label='End Window', command=root.quit)
    
    root.title("Street visual attention")
    root.geometry("500x700")
    root['background']='#0BB5FF'
    
def spike_window():
    global frame
    frame.destroy()
    frame = Frame(root)
    frame.grid()
    Label(frame, text ="Input Neurons").grid(row=0,pady = 5)
    Label(frame, text ="Runtime").grid(row=1,pady = 5)
    btn = Button(frame, text ='Choose image', command = open_img).grid(row = 8, columnspan = 1)
    btn2 = Button(frame, text ='Execute', command = give_spikes).grid(row = 9, columnspan = 1)
    neurons = IntVar()
    runtime = IntVar()
    Entry(frame,textvariable = neurons).grid(row=0,column=1,pady = 2)
    Entry(frame,textvariable = runtime).grid(row=3,column=1,pady = 2)

def compare_window():
    global frame
    frame.destroy()
    frame = Frame(root)
    frame.grid()
    Label(frame, text ="Input Neurons").grid(row=0,pady = 5)
    Label(frame, text ="Runtime").grid(row=1,pady = 5)
    btn = Button(frame, text ='Choose image', command = open_img).grid(row = 8, columnspan = 1)
    btn2 = Button(frame, text ='Execute', command = give_spikes).grid(row = 9, columnspan = 1)
    neurons = IntVar()
    runtime = IntVar()
    Entry(frame,textvariable = neurons).grid(row=0,column=1,pady = 2)
    
root = Tk()

# Allow Window to be resizable
root.resizable(width = True, height = True)
frame = Frame(root)
#frame.config(background='#0BB5FF')
frame.grid()

get_normal_page()
  
# Label is what output will be 
# show on the window
Label(frame, text ="Input Neurons").grid(row=0,pady = 5)
Label(frame, text ="Gaussian kernel size").grid(row=1,pady = 5)
Label(frame, text ="Orientations").grid(row=2,pady = 5)
Label(frame, text ="Runtime").grid(row=3,pady = 5)
orientation = IntVar()
Radiobutton(frame, text='2', variable=orientation, value=2).grid(row=4,column = 1,columnspan = 2,pady = 5)   # Change to horizontal/vertical, diagonal/co-diag, both
Radiobutton(frame, text='4', variable=orientation, value=4).grid(row=5,column = 1,pady = 5)
Label(frame, text ="Neuron Type").grid(row=4,pady = 5)
neuron_type = IntVar()
Radiobutton(frame, text='IF_curr_exp', variable=neuron_type, value=1).grid(row=6,column = 0,columnspan = 2,pady = 5)
Radiobutton(frame, text='Other', variable=neuron_type, value=2).grid(row=7,column = 0,pady = 5)
neurons = IntVar()
kernel_size = IntVar()
runtime = IntVar()
Entry(frame,textvariable = neurons).grid(row=0,column=1,pady = 2)
Entry(frame,textvariable = kernel_size).grid(row=1,column=1,pady = 2)
Entry(frame,textvariable = runtime).grid(row=3,column=1,pady = 2)

btn = Button(frame, text ='Choose image', command = open_img).grid(row = 8, columnspan = 1)
btn2 = Button(frame, text ='Execute', command = give_spikes).grid(row = 9, columnspan = 1)
  
root.mainloop()
